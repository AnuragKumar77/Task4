<?php
session_start();
if (isset($_SESSION["email_id"])) {
  header("Location: welcome.php");
}
?>
<?php
require_once "config.php";

if (isset($_POST["login"])) {
  $email_id = $_POST["email_id"];
  $password = $_POST["password"];



  $sql = "SELECT login.*,accesstype.type AS type_name from login
  JOIN usertype ON login.id = usertype.user_id
  JOIN accesstype ON usertype.access_type_id = accesstype.type 
  WHERE email_id = '$email_id'";
 
  $result = mysqli_query($connection, $sql);
  $userdata = mysqli_num_rows($result);


    if ($userdata == 1) {

        while ($row = mysqli_fetch_assoc($result)) {
            if (password_verify($password, $row['password'])) {
                session_start();
                $_SESSION['loggedin'] = true;
                $_SESSION['email_id'] = $email_id;
                $_SESSION['type'] = $row['type_name'];
                header("Location: welcome.php");
            } else {
              echo "<div class='alert alert-danger'> Sorry Password does not match</div>";
            }
        }
    } else {
      echo "<div class='alert alert-danger'>SORRY SOMETHING WENT WRONG</div>";
    }
}

?>
<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
  <meta charset="UTF-8">
  <title> Registration Form </title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>

<body>
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark" >
    <a class="navbar-brand" href="#">ANURAG KUMAR</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavDropdown">
      <ul class="navbar-nav">
        <li class="nav-item active">
          <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="registration.php">Register</a>
        </li>
      </ul>
    </div>
  </nav>
  <div class="container d-flex justify-content-center align-items-center" style="min-height: 80vh;">
    
    <form class="border shadow p-3 rounded" style="width: 450px;" action="" method="post" >
    <h3 style="text-align:center" >Login Here</h3>
      <div class="mb-3">
        <label for="inputEmail4">Email ID</label>
        <input type="email" class="form-control" name="email_id" placeholder="Enter Your Email id">
      </div>
      <div class="form-group">
        <label for="inputEmail4">Password</label>
        <input type="password" class="form-control" name="password" placeholder="Enter Your Password">
      </div>
    <br>
      <div class="form-btn">
        <input type="submit" class="btn btn-primary" value="Login" name="login">
      </div>
      <br>
      <div>
        <div>
          <p style="text-align:center" >Not Registered Yet Plz Click On Register Button</p>
        </div>
      </div>
    </form>
  </div>
</body>

</html>