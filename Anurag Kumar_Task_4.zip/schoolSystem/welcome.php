<?php
session_start();

if (empty($_SESSION['email_id'])) {
  header("Location: login.php");
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
  <title>Welcome Page</title>
  <style>
    ul {
      list-style-type: none;
      margin: 0;
      padding: 0;
      width: 200px;
      background-color: white;
      border: 1px solid #555;
    }

    li a {
      display: block;
      color: black;
      padding: 8px 16px;
      text-decoration: none;
    }

    li {
      text-align: center;
      border-bottom: 1px solid #555;
    }

    li:last-child {
      border-bottom: none;
    }

    li a.active {
      background-color: burlywood;
      color: whitesmoke;
    }

    li a:hover:not(.active) {
      background-color: burlywood;
      color: white;
    }
  </style>
</head>

<body>
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <a class="navbar-brand" href="#">School Management</a>
    <div class="collapse navbar-collapse">
      <ul>
        <li class="nav-item">
          <a class="nav-link" href="logout.php">Logout</a>
        </li>
      </ul>
    </div>
    <ul class="ml-auto">
      <li> <a class="nav-link" href="#"> <img src="https://img.icons8.com/metro/26/000000/guest-male.png"><?php echo "Welcome " . $_SESSION['type'] ?></a></li>
    </ul>
  </nav>
  <h5 style="text-align:center"><?php echo "Welcome " . $_SESSION['type'] ?>! You can now use this website</h5>
  <?php
  if ($_SESSION['type'] == "Admin" || $_SESSION['type'] == "Teacher") { ?>
    <ul>
      <li><a class="active" href="#home">Home</a></li>
      <li><a href="Insert_subject.php">Subject</a></li>
      <li><a href="insert_standard.php">Standard</a></li>
      <li><a href="Insert_chapter.php">Chapter</a></li>
      <li><a href="assign_chapter.php">Assign Chapters to Given Subjects</a></li>
      <li><a href="assign_subject.php">Assign Subject to Given Standards</a></li>
      <li><a href="assign_student.php">Assign Students to Given Standards</a></li>
    </ul>
  <?php } ?>
</body>

</html>