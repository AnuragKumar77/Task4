<?php

$connection = mysqli_connect('localhost','root','root','schoolSystem');

if(!$connection){
    die("Database connection failed");
}

?>