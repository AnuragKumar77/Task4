<?php 
include 'config.php';
if(isset($_GET['delete_id'])){
    $id = $_GET['delete_id'];

    $sql = "DELETE FROM standard WHERE standard_id = $id";
    $result = mysqli_query($connection,$sql);
    if($result){
        header('location:display_standard.php');
    }else{
        die(mysqli_error($connection));
    }
}