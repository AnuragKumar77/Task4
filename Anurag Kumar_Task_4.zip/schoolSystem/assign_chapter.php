<?php
session_start();
if (!isset($_SESSION["email_id"])) {
    header("Location: welcome.php");
}
?>
<?php
require_once "config.php";
?>



<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap-theme.min.css" crossorigin="anonymous">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <title>Assign Chapter</title>
</head>

<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <a class="navbar-brand" href="#">ANURAG KUMAR</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavDropdown">
            <ul class="navbar-nav">
                <li class="nav-item active">
                    <a class="nav-link" href="welcome.php">Home <span class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="logout.php">Logout</a>
                </li>
            </ul>
        </div>
    </nav>
    <br>
    <div class="container d-flex justify-content-center align-items-center" style="min-height: 60vh;">
    <div class="border shadow p-3 rounded" style="width: 450px;">
    <form action="" method="post">
        <label> Select Subject :</label>
        <select class="form-select" name="subject_name">
            <option value="">Select Subject</option>
            <?php
            $select = "SELECT * FROM subject";
            $select_query = mysqli_query($connection, $select);

            while ($row = mysqli_fetch_assoc($select_query)) { 
                $subject_value = $row['subject_name'];
                $subject_id = $row['subject_id'];
                echo "<option value='$subject_id'>" . $subject_value. "</option>";
                
            } ?>  
        </select>
        <br>
        <label> Select chapter :</label>
        <select class="form-select" name="chapter_name">
            <option value="">Select Chapter</option>
            <?php
            $select_chapter = "SELECT * FROM chapter";
            $chapter_result = mysqli_query($connection, $select_chapter);

            while ($row = mysqli_fetch_assoc($chapter_result)) {
                $chapter_value = $row['chapter_name'];
                $chapter_id = $row['chapter_id'];
                echo "<option value='$chapter_id'>" . $chapter_value . "</option>";
                
        }
            ?>
        </select>
        <br>
        <input class="btn btn-primary" type="submit" name="assign" value="Assign">
    </form>
    </div>
    </div>
</body>

</html>
<?php
if (isset($_POST['assign'])) {
    $subject_name = $_POST['subject_name'];
    $chapter_name = $_POST['chapter_name'];

    $sql = "INSERT INTO `assign` (`subject_id`, `chapter_id`) VALUES ('$subject_name', '$chapter_name')";
    $result = mysqli_query($connection, $sql);
}
?>
