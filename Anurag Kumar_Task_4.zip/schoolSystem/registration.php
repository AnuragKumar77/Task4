<?php
require_once "config.php";

if (isset($_POST["submit"])) {
  $username = trim($_POST["username"]);
  $email_id = trim($_POST["email_id"]);
  $password = $_POST["password"];
  $confirm_password = $_POST["confirm_password"];
  $type = $_POST["type"];

  $passwordHash = password_hash($password, PASSWORD_DEFAULT);


  $errors = array();

  if (empty($username) or empty($email_id)  or empty($password) or empty($confirm_password)) {
    array_push($errors, "All Fields are Required");
  }
  if (!filter_var($email_id, FILTER_VALIDATE_EMAIL)) {
    array_push($errors, "Email is not valid");
  }
  if (strlen($password) < 5) {
    array_push($errors, "Password cannot be less than 5 characters");
  }
  if ($password !== $confirm_password) {
    array_push($errors, "Password should match");
  }
  $sql = "SELECT * FROM login WHERE email_id = '$email_id'";
  $result = mysqli_query($connection, $sql);
  $rowCount = mysqli_num_rows($result);
  if ($rowCount > 0) {
    array_push($errors, "Email already exists!");
  }
  if (count($errors) > 0) {
    foreach ($errors as $error) {
      echo "<div class = 'alert alert-danger'>$error</div>";
    }
  } else {
    $sql = "INSERT INTO login(username, email_id, password) VALUES ('$username', '$email_id', '$passwordHash')";
    $login_data = mysqli_query($connection, $sql);
    if ($login_data) {
        $query = "SELECT * FROM login WHERE email_id = '$email_id'";
        $result = mysqli_query($connection, $query);

        $userdata = mysqli_fetch_assoc($result);
        $enter = $userdata['id'];
        $userdata_type = "INSERT INTO usertype(user_id, access_type_id) VALUES ('$enter', '$type')";
        $userdata_type_result = mysqli_query($connection,$userdata_type);
        if($userdata_type_result){
            echo "<div class='alert alert-success'>Data inserted in UserType is successfully.</div>";
        }
        else{
            echo "Something went wrong... cannot redirect!";
        }
    }
    else{
        echo "Something went wrong... cannot redirect!";
    } 
  }
  mysqli_close($connection);
}


?>

<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
  <meta charset="UTF-8">
  <title> Registration Form </title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>

<body>
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark" >
    <a class="navbar-brand" href="#">ANURAG KUMAR</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavDropdown">
      <ul class="navbar-nav">
        <li class="nav-item active">
          <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="login.php">Login</a>
        </li>
      </ul>
    </div>
  </nav>
  <div class="container d-flex justify-content-center align-items-center" style="min-height: 100vh;">
    
    <form class="border shadow p-3 rounded" style="width: 450px;" action="" method="post" >
    <h3 style="text-align:center" >Register Here</h3>
      <div class="mb-3">
        <label for="inputEmail4">Username</label>
        <input type="text" class="form-control" name="username" placeholder="Full Name">
      </div>
      <div class="mb-3">
        <label for="inputEmail4">Email ID</label>
        <input type="email" class="form-control" name="email_id" placeholder="Enter Your Email id">
      </div>
      <div class="form-group">
        <label for="inputEmail4">Password</label>
        <input type="password" class="form-control" name="password" placeholder="Enter Your Password">
      </div>
      <div class="form-group">
        <label for="inputEmail4">Confirm Password</label>
        <input type="password" class="form-control" name="confirm_password" placeholder="Confirm Password">
      </div>
      <label  class="form-label">AccessType(select one):</label>
    <select class="form-select" name="type">
    <?php
                $Sql = "SELECT * FROM accesstype";
                $result = mysqli_query($connection, $Sql);
                while ($row = mysqli_fetch_assoc($result)){

                    $type = $row['type'];

                    echo "<option value='$type'> $type</option>";
             
                ?>
                <?php }  ?>
    </select>
    <br>
      <div class="form-btn">
        <input type="submit" class="btn btn-primary" value="Register" name="submit">
      </div>
      <br>
      <div>
        <div>
          <p style="text-align:center" >Already Registered Plz Click on Login Button</p>
        </div>
      </div>
    </form>
  </div>
</body>

</html>