<?php 
include 'config.php';
if(isset($_GET['delete_id'])){
    $id = $_GET['delete_id'];

    $sql = "DELETE FROM chapter WHERE chapter_id = $id";
    $result = mysqli_query($connection,$sql);
    if($result){
        header('location:display_chapter.php');
    }else{
        die(mysqli_error($connection));
    }
}