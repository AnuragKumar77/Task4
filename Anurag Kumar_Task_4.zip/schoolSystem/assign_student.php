<?php
session_start();
if (!isset($_SESSION["email_id"])) {
    header("Location: welcome.php");
}
?>
<?php
require_once "config.php";
?>



<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap-theme.min.css" crossorigin="anonymous">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <title>Assign Student</title>
</head>

<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <a class="navbar-brand" href="#">ANURAG KUMAR</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavDropdown">
            <ul class="navbar-nav">
                <li class="nav-item active">
                    <a class="nav-link" href="welcome.php">Home <span class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="logout.php">Logout</a>
                </li>
            </ul>
        </div>
    </nav>
    <br>
    <div class="container d-flex justify-content-center align-items-center" style="min-height: 60vh;">
    <div class="border shadow p-3 rounded" style="width: 450px;">
    <form action="" method="post">
        <label> Select Student :</label>
        <select class="form-select" name="username">
            <option value="">Select Student</option>
            <?php
            $sql = "SELECT login.*,accesstype.type AS type_name from login
            JOIN usertype ON login.id = usertype.user_id
            JOIN accesstype ON usertype.access_type_id = accesstype.type 
            WHERE accesstype.type = 'student'";
            $select_query = mysqli_query($connection, $sql);

            while ($row = mysqli_fetch_assoc($select_query)) { 
                $student_value = $row['username'];
                $student_id = $row['id'];
                echo "<option value='$student_id'>" . $student_value. "</option>";
                
            } ?>  
        </select>
        <br>
        <label> Select Standard :</label>
        <select class="form-select" name="standard_name">
            <option value="">Select Standard</option>
            <?php
            $select_standard = "SELECT * FROM standard";
            $standard_result = mysqli_query($connection, $select_standard);

            while ($row = mysqli_fetch_assoc($standard_result)) {
                $standard_value = $row['standard_name'];
                $standard_id = $row['standard_id'];
                echo "<option value='$standard_id'>" . $standard_value . "</option>";
                
        }
            ?>
        </select>
        <br>
        <input class="btn btn-primary" type="submit" name="assign" value="Assign">
    </form>
    </div>
    </div>
</body>

</html>
<?php
if (isset($_POST['assign'])) {
    $student_name = $_POST['username'];
    $standard_name = $_POST['standard_name'];

    $sql = "INSERT INTO `assign_student` (`student_id`, `standard_id`) VALUES ('$student_name', '$standard_name')";
    $result = mysqli_query($connection, $sql);
}
?>