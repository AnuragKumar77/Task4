<?php
session_start();
if (!isset($_SESSION["email_id"])) {
  header("Location: welcome.php");
}
?>
<?php
require_once "config.php";

if (isset($_POST['submit'])) {
    $subject_name = $_POST['subject_name'];


    $sql = "INSERT INTO subject(subject_name) VALUES ('$subject_name')";
    $result = mysqli_query($connection, $sql);

    if ($result) {
        echo "<div class='alert alert-success'>New Subject Added Successfully.</div>";
    } else {
        echo "<div class='alert alert-danger'>SORRY SOMETHING WENT WRONG</div>";
    }
    mysqli_close($connection);
}




?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Insert Subject</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <a class="navbar-brand" href="#">ANURAG KUMAR</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavDropdown">
            <ul class="navbar-nav">
                <li class="nav-item active">
                    <a class="nav-link" href="display_subject.php">Home <span class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="logout.php">Logout</a>
                </li>
            </ul>
        </div>
    </nav>
    <div class="container d-flex justify-content-center align-items-center" style="min-height: 60vh;">

        <form class="border shadow p-3 rounded" style="width: 450px;" action="" method="post">
            <h3 style="text-align:center">SUBJECT NAME HERE</h3>
            <div class="mb-3">
                <label for="inputEmail4">Subject Name</label>
                <input type="text" class="form-control" name="subject_name" placeholder=" Add New Subject">
            </div>
            <div class="form-btn">
                <input type="submit" class="btn btn-primary" value="Add New Subject" name="submit">
            </div>
            <br>
            <div>
                <div>
                    <p style="text-align:center">Click on Back Button</p>
                </div>
            </div>
        </form>
    </div>
</body>

</html>