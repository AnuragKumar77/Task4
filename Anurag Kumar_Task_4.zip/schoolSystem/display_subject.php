<?php
session_start();
if (!isset($_SESSION["email_id"])) {
  header("Location: welcome.php");
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Display Record</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap-theme.min.css" crossorigin="anonymous">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <a class="navbar-brand" href="#">ANURAG KUMAR</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavDropdown">
            <ul class="navbar-nav">
                <li class="nav-item active">
                    <a class="nav-link" href="welcome.php">Home <span class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="logout.php">Logout</a>
                </li>
            </ul>
        </div>
    </nav>
    <br>
    <div class="container">
    <a href="add_subject.php" class="btn btn-dark mb-3">Add New Subject</a>
        <table class="table" border='2px' cellpadding='5px' cellspacing='0px'>
            <thead>
                <tr>
                    <th scope="col">Subject ID</th>
                    <th scope="col">Subject Name</th>
                    <th scope="col">Edit</th>
                    <th scope="col">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                require_once "config.php";
                $Sql = "SELECT * FROM subject";
                $result = mysqli_query($connection, $Sql);
                if (mysqli_num_rows($result) > 0) {
                    while ($row = mysqli_fetch_assoc($result)) {
                ?>

                        <tr>
                            <td><?php echo $row['subject_id']; ?></td>
                            <td><?php echo $row['subject_name']; ?></td>
                            <td>
                                <button class="btn btn-primary"><a href="update_subject.php?update_id=<?php echo $row['subject_id']; ?>" class="text-light">Update</a></button>
                            </td>
                            <td>
                                <button class="btn btn-danger"><a href="delete_subject.php?delete_id=<?php echo $row['subject_id']; ?>" class="text-light">Delete</a></button>
                            </td>
                        </tr>
                <?php
                    }
                } else {
                    echo "<div class='alert alert-danger'>No Records Found..</div>";
                }
                ?>
            </tbody>
        </table>
    </div>


</body>

</html>